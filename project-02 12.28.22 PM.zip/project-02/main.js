$(document).ready(function() {

	$('object').jqFloat({
		width: 100,
		height: 100,
		speed: 1000
	});

  

floating({
	content: "💘",
	number: 3,
	duration: 11
  });
  floating({
	content: "🍉",
	number: 5,
	duration: 8
  });
  floating({
	content: "🍊",
	number: 5,
	duration: 15

  });
  floating({
	content: "🤙🏾",
	number: 1,
	duration: 10,
	size: 6
  });

$("divbutton").hover(function( ) {$(div).css("background-image", "url(img/hibutton-02.png)"); 
});